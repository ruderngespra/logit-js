### Logit-Implementation for Atom

### Install

1. Download [logit-atom.tar.gz](logit-atom.tar.gz).
2. Create a new directory, cd into it and extract the package:
   ```
   tar xvzf logit-atom.tar.gz
   ```
3. Run `apm install` and `apm link`.
4. Restart Atom.
