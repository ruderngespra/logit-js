### Logit-Implementation for Atom

Please notice that this plugin is not yet stable. If you still want to try it out you can do so by doing the following:

1. Download (logit-atom.tar.gz)[logit-atom.tar.gz]
2. Extract it:
   ```
   tar xvzf logit-atom.tar.gz
   ```
3. Cd into the the created folder and run `apm install` and `apm link`.
4. Restart Atom.
