### Logit-Implementation for Atom

Please notice that this plugin is not yet stable. If you still want to try it out you can do so by doing the following:

1. Download this folder.
2. Cd into the the folder and run `apm install` and `apm link`.
4. Restart Atom.
